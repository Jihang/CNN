#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 16:07:58 2020

@author: jihangliu
"""
import torch
import numpy as np
import os
import pandas as pd
import time
import matplotlib.pyplot as plt

max_loss = 2e1
max_grad_norm = 1e0


weight_decay_initprocesscov_net = 0e-8
lr_mesnet = {'cov_net': 1e-4,
    'cov_lin': 1e-4,
    }
weight_decay_mesnet = {'cov_net': 1e-8,
    'cov_lin': 1e-8,
    }

criterion = torch.nn.MSELoss(reduction="sum")  #MSELoss Calculate Loss for vector 
lr = 1e-3
min_lr = 1e-5





class MesNet(torch.nn.Module):
        def __init__(self):
            super(MesNet, self).__init__() 

            self.cov_net = torch.nn.Sequential(torch.nn.Conv1d(3, 64, 2,padding=2),
                      # torch.nn.ReplicationPad1d(4)
                       torch.nn.Tanh(),
                       torch.nn.Dropout(p=0.5),
                       torch.nn.Conv1d(64, 128, 2, dilation=3),
                      # torch.nn.ReplicationPad1d(4),
                       torch.nn.Tanh(),
                       torch.nn.Dropout(p=0.5),
                       ).double()
            "CNN for measurement covariance"
            self.cov_lin = torch.nn.Sequential(torch.nn.Linear(128, 32),
                                              torch.nn.Tanh(),
                                              torch.nn.Linear(32, 3),
                                              torch.nn.Tanh()
                                              ).double()
            # self.cov_lin[0].bias.data[:] /= 100
            # self.cov_lin[0].weight.data[:] /= 100

        def forward(self, u):
            y_cov = self.cov_net(u)
            y_cov = y_cov.view(y_cov.size(0),-1)
            z_cov = self.cov_lin(y_cov)
            return z_cov
            #measurements_covs = (iekf.cov0_measurement.unsqueeze(0) * (10**z_cov_net))
            

def train_filter(args):
    ###Load Data 
    print("Start loading data..")
    v, acc = loadData()
    print("Loading data complete.")
    ##Finish Loading Data 

    model = MesNet()
    optimizer = torch.optim.Adam(params = model.parameters(),lr = lr)
    start_time = time.time()
    lossPlot = []
    for epoch in range(args):
        
        
        # train loop
        loss_train = 0
        running_loss = 0
        for i, dataset in enumerate(acc):
            model.train()
            output = model(torch.from_numpy(dataset).unsqueeze(2))
            print(np.all(output.detach().numpy() == 0))
            # print(output)
            optimizer.zero_grad()     #Zero it for every loop 
            loss = criterion(output, torch.from_numpy(v[i]))
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            print(i)
        
        average = running_loss/i
        lossPlot.append(average)
        print("average loss")
        print(average)
        # using RealSense v and acc
        print("Amount of time spent for 1 epoch: {}s\n".format(int(time.time() - start_time)))
        print(epoch)
        start_time = time.time()
    
    ##Validation 
    valid_loss = 0
    dfacc = pd.read_csv('AITestData/Data_' + str(2) + '/Realsense_acc_Data_' + str(2), delimiter = ' ')
    dfacc = dfacc.to_numpy()
    output = model(torch.from_numpy(dfacc).unsqueeze(2))
    output = output.detach().numpy()
    velocity = np.cumsum(output,axis = 0)
    print(output)
    print(output[:,0].shape)
    
    plt.plot(lossPlot)
    plt.ylabel('loss')
    plt.show()
    plt.plot(output[:,0])   #x
    plt.ylabel('x')
    plt.show()
    plt.plot(output[:,1])   #y
    plt.ylabel('y')
    plt.show()
    plt.plot(output[:,2])    #z
    plt.ylabel('z')
    plt.show()
    
    plt.plot(velocity[:,0])
    plt.plot(velocity[:,1])
    plt.plot(velocity[:,2])
    plt.legend(['x','y','z'])
    plt.show()
    
    return velocity

    
        
        
def loadData():
    v = []
    acc = []
    for i in range(2,9):
        #Read 
        df = pd.read_csv('AITestData/Data_' + str(i) + '/Realsense_Velocity_Data_' + str(i), delimiter = ' ')
        df = df.to_numpy()
        print(df.shape)
        v.append(df[:,:])
        
        
        dfacc = pd.read_csv('AITestData/Data_' + str(i) + '/Realsense_acc_Data_' + str(i), delimiter = ' ')
        dfacc = dfacc.to_numpy()
        acc.append(dfacc[:,:])
        

    return v, acc
        

    
    

if __name__ == '__main__':
    args = 100
    velocity = train_filter(args)
    

